local M = {}

local isTimerRunning = false
local timerRemaining = 0
local timerMax = 0

function startTimer(time)
    time = jsonDecode(time)
    time = tonumber(time.time)

    print("Timer started for " .. time .. " seconds!")
    local minutes = math.floor(time / 60)
    local seconds = time % 60
    guihooks.trigger('toastrMsg', {type = "info", title = "Timer Info:", msg = string.format("Started for %02d:%02d", minutes, seconds), config = {timeOut = 5000}})

end

function stopTimer()
    isTimerRunning = false
    print("Timer stopped!")
    guihooks.trigger('toastrMsg', {type = "info", title = "Timer Info:", msg = "TIMER STOPPED!", config = {timeOut = 3000}})
end

-- function startTimerCoroutine()
--     local co = coroutine.create(function()
--         while isTimerRunning and timerRemaining > 0 do
--             print("Timer tick: " .. timerRemaining)
--             if timerRemaining % 20 == 0 then
--                 local minutes = math.floor(timerRemaining / 60)
--                 local seconds = timerRemaining % 60
--                 guihooks.trigger('Message', {msg = string.format("[TIMER] %02d:%02d remaining!", minutes, seconds), ttl = 5.0, category = "settings", icon = "settings"})
--             end
--             timerRemaining = timerRemaining - 1
--             MP.sleep(1)
--             coroutine.resume(co)
--         end

--         if isTimerRunning then
--             guihooks.trigger('toastrMsg', {type = "info", title = "Timer Info:", msg = "TIME IS UP! TIMER FINISHED!", config = {timeOut = 3000}})
--         end
--         timerMax = 0
--         timerRemaining = 0
--         isTimerRunning = false
--     end)

--     coroutine.resume(co)
-- end

function updateTimer(time)
    print("updateTimer")
    print(time)
    time = jsonDecode(time)
    time = tonumber(time.time)
 
    if time == nil then return end
 
    local minutes = math.floor(time / 60)
    local seconds = time % 60
    guihooks.trigger('Message', {msg = string.format("[TIMER] %02d:%02d remaining!", minutes, seconds), ttl = 5.0, category = "settings", icon = "settings"})
end

if MPGameNetwork then AddEventHandler("onStartTimer", startTimer) end
if MPGameNetwork then AddEventHandler("onStopTimer", stopTimer) end
if MPGameNetwork then AddEventHandler("updateTimer", updateTimer) end

M.onStartTimer = startTimer
M.onStopTimer = stopTimer
M.updateTimer = updateTimer

return M